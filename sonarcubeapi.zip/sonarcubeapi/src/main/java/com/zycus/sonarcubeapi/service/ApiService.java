package com.zycus.sonarcubeapi.service;

import java.util.Map;

import com.zycus.sonarcubeapi.model.ApiRequest;
import com.zycus.sonarcubeapi.model.Issue;

public interface ApiService {
	
	public Map<String, Issue> createApiRequestURL(ApiRequest request);
	
	public Map<String, Issue> findIssuesForAuthor(Map<String, Issue>issues,String author);
	
	public int getTotalIssues();
}
