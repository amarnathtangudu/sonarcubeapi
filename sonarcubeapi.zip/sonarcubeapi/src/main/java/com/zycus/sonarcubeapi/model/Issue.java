package com.zycus.sonarcubeapi.model;

import java.util.List;

public class Issue {
	private String issueKey;
	private String component;
	private long line;
	private String message;
	private String author;
	private String createdDate;
	private String effort;
	private String displayKey;
	private String rule;

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}


	public String getIssueKey() {
		return issueKey;
	}

	public void setIssueKey(String issueKey) {
		this.issueKey = issueKey;
	}

	public String getComponent() {
		return component;
	}

	public Issue() {
		super();
	}

	public void setComponent(String component) {
		this.component = component;
	}

	public long getLine() {
		return line;
	}

	public void setLine(long line) {
		this.line = line;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Issue(String issueKey, String component, long line, String message, String author, String createdDate,
			String effort, String displayKey, String rule) {
		super();
		this.issueKey = issueKey;
		this.component = component;
		this.line = line;
		this.message = message;
		this.author = author;
		this.createdDate = createdDate;
		this.effort = effort;
		this.displayKey = displayKey;
		this.rule = rule;
	}

	@Override
	public String toString() {
		return "Issue [issueKey=" + issueKey + ", component=" + component + ", line=" + line + ", message=" + message
				+ ", author=" + author + ", createdDate=" + createdDate + ", effort=" + effort + ", displayKey="
				+ displayKey + ", rule=" + rule+"]";
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getEffort() {
		return effort;
	}

	public void setEffort(String effort) {
		this.effort = effort;
	}

	public String getDisplayKey() {
		return displayKey;
	}

	public void setDisplayKey(String displayKey) {
		this.displayKey = displayKey;
	}
}
