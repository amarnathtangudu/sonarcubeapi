package com.zycus.sonarcubeapi.service;

import java.util.Map;

import com.zycus.sonarcubeapi.model.Issue;

public interface JSONService {
	public Map<String, Issue> jsonToMap(String fileName);
}
