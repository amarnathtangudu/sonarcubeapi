package com.zycus.sonarcubeapi.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.sonarcubeapi.model.ApiRequest;
import com.zycus.sonarcubeapi.model.Issue;
import com.zycus.sonarcubeapi.service.ApiService;
import com.zycus.sonarcubeapi.util.CommonUtilities;

@Controller
public class APIController {

	@Autowired
	ApiService apiService;

	Logger logger = Logger.getLogger(APIController.class);
	Map<String, Issue> allIssues;
	Map<String, Issue> authorIssues;
	Map<String, Integer> authors;
	static int totalIssues;
	static int totalPages;
	static int currentPage;
	static ApiRequest myRequest;

	public void setApiService(ApiService apiService) {
		this.apiService = apiService;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}

	/**
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "/searchIssues", "/", "/index" }, method = RequestMethod.GET)
	public String getsearchIssuesPage(Model model) {
		List<String> projects = CommonUtilities.getAllProjects();
		model.addAttribute("projects", projects);
		ApiRequest apiRequest = new ApiRequest();
		model.addAttribute("requestObj", apiRequest);
		myRequest = apiRequest;
		logger.info("Opening searchissues.jsp");
		return "searchissues";
	}

	@RequestMapping(value = "/createApiRequest", method = RequestMethod.POST)
	public String createAPIRequest(@ModelAttribute("requestObj") ApiRequest request, Model model) {
		myRequest = request;
		myRequest.setP(1);
		logger.info("ApiRequest:" + myRequest.toString());
		Map<String, Issue> issues = apiService.createApiRequestURL(myRequest);
		currentPage = myRequest.getP();
		totalIssues = apiService.getTotalIssues();
		int ps = Integer.parseInt(myRequest.getPs());
		if (totalIssues % ps == 0) {
			totalPages = totalIssues / ps;
		} else {
			totalPages = (totalIssues / ps) + 1;
		}
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("currentPage", currentPage);
		logger.info("Total Issues Found : " + issues.size());
		allIssues = issues;
		authors = CommonUtilities.getAuthors(allIssues);
		int totalCount = CommonUtilities.getTotalIssues(authors);
		model.addAttribute("totalIssues", totalCount);
		logger.info("Total Authors found : " + authors.size());
		model.addAttribute("authors", authors);
		logger.info("Opening Page listauthors.jsp");
		model.addAttribute("requestObj", myRequest);
		return "listauthors";
	}

	@RequestMapping(value = "**/createApiRequest/page/{pn}", method = RequestMethod.GET)
	public String createAPIRequest1(@PathVariable("pn") String pn, Model model) {
		myRequest.setP(Integer.parseInt(pn));
		logger.info("ApiRequest:" + myRequest.toString());
		Map<String, Issue> issues = apiService.createApiRequestURL(myRequest);
		currentPage = myRequest.getP();
		totalIssues = apiService.getTotalIssues();
		int ps = Integer.parseInt(myRequest.getPs());
		if (totalIssues % ps == 0) {
			totalPages = totalIssues / ps;
		} else {
			totalPages = (totalIssues / ps) + 1;
		}
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("currentPage", currentPage);
		logger.info("Total Issues Found : " + issues.size());
		allIssues = issues;
		authors = CommonUtilities.getAuthors(allIssues);
		int totalCount = CommonUtilities.getTotalIssues(authors);
		model.addAttribute("totalIssues", totalCount);
		logger.info("Total Authors found : " + authors.size());
		model.addAttribute("authors", authors);
		logger.info("Opening Page listauthors.jsp");
		model.addAttribute("requestObj", myRequest);
		
		return "listauthors";
	}

	@RequestMapping(value = "**/createApiRequest/page", method = RequestMethod.GET)
	public String createAPIRequest1(@ModelAttribute("requestObj") ApiRequest request, Model model) {
		myRequest.setP(request.getP());
		logger.info("ApiRequest:" + myRequest.toString());
		Map<String, Issue> issues = apiService.createApiRequestURL(myRequest);
		currentPage = myRequest.getP();
		totalIssues = apiService.getTotalIssues();
		int ps = Integer.parseInt(myRequest.getPs());
		if (totalIssues % ps == 0) {
			totalPages = totalIssues / ps;
		} else {
			totalPages = (totalIssues / ps) + 1;
		}
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("currentPage", currentPage);
		logger.info("Total Issues Found : " + issues.size());
		allIssues = issues;
		authors = CommonUtilities.getAuthors(allIssues);
		int totalCount = CommonUtilities.getTotalIssues(authors);
		model.addAttribute("totalIssues", totalCount);
		logger.info("Total Authors found : " + authors.size());
		model.addAttribute("authors", authors);
		logger.info("Opening Page listauthors.jsp");
		model.addAttribute("requestObj", myRequest);
		return "listauthors";
	}

	@RequestMapping(value = "/author/{author}")
	public String showAuthorIssues(@PathVariable("author") String author, Model model) {
		logger.info("Finding issues for author : " + author);
		authorIssues = apiService.findIssuesForAuthor(allIssues, author);
		logger.info("Total author specific issues found : " + authorIssues.size());
		model.addAttribute("issues", authorIssues);
		logger.info("Opening Page : listissues.jsp");
		return "listissues";
	}

	@RequestMapping(value = "/issue/{key}")
	public String showIssueDetails(@PathVariable("key") String key, Model model) {
		logger.info("Displaying details for issue key : " + key);
		Issue issue = authorIssues.get(key);
		model.addAttribute("issue", issue);
		logger.info("Opening Page issue.jsp");
		return "issue";
	}

}
