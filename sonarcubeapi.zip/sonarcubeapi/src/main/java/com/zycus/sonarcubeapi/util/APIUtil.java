package com.zycus.sonarcubeapi.util;

import org.apache.log4j.Logger;


public class APIUtil {
	Logger logger=Logger.getLogger(APIUtil.class);
	
	public static boolean validateResponseCodes(int responseCode) {
		boolean status = false;
		switch (responseCode) {
		case 200:
		case 201:
		case 202:
		case 204:
			status = true;
			break;
		default:
			break;
		}
		return status;
	}
}
