package com.zycus.sonarcubeapi.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.aspectj.util.FileUtil;
import org.springframework.stereotype.Service;

import com.zycus.sonarcubeapi.constants.Constants;
import com.zycus.sonarcubeapi.model.ApiRequest;
import com.zycus.sonarcubeapi.model.Issue;
import com.zycus.sonarcubeapi.service.ApiService;
import com.zycus.sonarcubeapi.service.JSONService;
import com.zycus.sonarcubeapi.util.CommonUtilities;
import com.zycus.sonarcubeapi.util.JSONUtil;

@Service
public class ApiServiceImpl implements ApiService {

	InputStream input = null;
	JSONService jsonService;
	Logger logger = Logger.getLogger(ApiServiceImpl.class);
	static int totalIssues = 0;

	public void setLogger(Logger logger) {
		this.logger = logger;
	}

	public void setJsonService(JSONService jsonService) {
		this.jsonService = jsonService;
	}

	public Map<String, Issue> createApiRequestURL(ApiRequest request) {
		URL myURL = null;
		BasicConfigurator.configure();
		BufferedReader br = null;
		FileWriter fstream = null;
		int output;
		HttpURLConnection myURLConnection = null;
		String baseURL = null;
		String apiPath = null;
		String requestURL = null;
		String filePath = null;
		try {
			baseURL = Constants.baseURL;
			logger.info("Base URL: " + baseURL);
			apiPath = Constants.apiPath;
			logger.info("API Path: " + apiPath);
			requestURL = baseURL.concat(apiPath);
			logger.info("Request URL: " + request);
			requestURL = addQueryParams(requestURL, request);
			logger.info("Complete Request URL after adding query params: " + requestURL);
			myURL = new URL(requestURL);
			logger.info("Opening Connection");
			myURLConnection = (HttpURLConnection) myURL.openConnection();
			myURLConnection.setRequestMethod(Constants.get);
			myURLConnection.setRequestProperty("Accept", "application/json");
			myURLConnection.setUseCaches(false);
			myURLConnection.setDoInput(true);
			myURLConnection.setDoOutput(true);
			if (!com.zycus.sonarcubeapi.util.APIUtil.validateResponseCodes(myURLConnection.getResponseCode())) {
				logger.error("Response Code: " + myURLConnection.getResponseCode());
				throw new RuntimeException("Request Failed");
			} else {
				logger.info("Response Code: " + myURLConnection.getResponseCode());
			}
			InputStream inputStream = myURLConnection.getInputStream();
			inputStream.mark(1000);
			br = new BufferedReader(new InputStreamReader(inputStream));
			
			ClassLoader classLoader = ApiService.class.getClassLoader();
			filePath=new File(classLoader.getResource(".").getFile()).getAbsolutePath()+File.separator; 
			String fileName = System.currentTimeMillis() + ".json";
			logger.info("Creating file : " + fileName);
			fstream = new FileWriter(filePath.concat(fileName));
			while ((output = br.read()) != -1) {
				fstream.write(output);
				fstream.flush();
			}
			logger.info("Created file: " + filePath + fileName);
			jsonService = new JSONServiceImpl();
			logger.info("Converting JSON data to Map");
			long l=(long) new JSONUtil().getValue(filePath.concat(fileName), "total");
			totalIssues= (int)l; 
			Map<String, Issue> issues = jsonService.jsonToMap(filePath.concat(fileName));
			return issues;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String addQueryParams(String requestURL, ApiRequest request) throws IOException {

		StringBuffer APIRequestURL = new StringBuffer(requestURL);
		APIRequestURL = APIRequestURL.append("?");
		if (!request.getSeverities().equalsIgnoreCase("-1")) {
			APIRequestURL = APIRequestURL.append("severities=").append(request.getSeverities()).append("&");
		}
		if (!request.getProjectKeys().equalsIgnoreCase("")) {
			APIRequestURL = APIRequestURL.append("projectKeys=")
					.append(CommonUtilities.getProjectKey(request.getProjectKeys())).append("&");
		}
		if (!request.getStatuses().equalsIgnoreCase("-1")) {
			APIRequestURL = APIRequestURL.append("statuses=").append(request.getStatuses()).append("&");
		}
		if (!request.getTypes().equalsIgnoreCase("-1")) {
			APIRequestURL = APIRequestURL.append("types=").append(request.getTypes()).append("&");
		}
		if (!request.getPs().equalsIgnoreCase("")) {
			APIRequestURL = APIRequestURL.append("ps=").append(request.getPs()).append("&");
		}
		APIRequestURL = APIRequestURL.append("p=").append(request.getP()).append("&");
		APIRequestURL = APIRequestURL.append("createdAfter=").append(request.getFormattedDate());

		return APIRequestURL.toString();

	}

	@Override
	public Map<String, Issue> findIssuesForAuthor(Map<String, Issue> issues, String author) {
		Map<String, Issue> myIssues = new HashMap<>();
		for (Map.Entry<String, Issue> entry : issues.entrySet()) {
			if (entry.getValue().getAuthor().equalsIgnoreCase(author)) {
				myIssues.put(entry.getKey(), entry.getValue());
			}
		}
		return myIssues;
	}

	@Override
	public int getTotalIssues() {
		return totalIssues;
	}
	
	

}
