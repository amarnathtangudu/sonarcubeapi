package com.zycus.sonarcubeapi.util;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class JSONUtil {
	Logger logger=Logger.getLogger(JSONUtil.class);
	public  Object getValue(String fileName, String key) {
		InputStream input = null;
		try {

			Object obj = new JSONParser().parse(new FileReader(fileName));

			// type casting obj to JSONObject
			JSONObject jo = (JSONObject) obj;

			// get the value corresponding to the key
			return jo.get(key);

		} catch (IOException | ParseException e) {
			e.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;

	}
	
	
}
