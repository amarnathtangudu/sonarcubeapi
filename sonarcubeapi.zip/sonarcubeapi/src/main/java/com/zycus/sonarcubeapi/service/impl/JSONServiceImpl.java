package com.zycus.sonarcubeapi.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;

import com.zycus.sonarcubeapi.constants.Constants;
import com.zycus.sonarcubeapi.model.Issue;
import com.zycus.sonarcubeapi.service.JSONService;
import com.zycus.sonarcubeapi.util.JSONUtil;

public class JSONServiceImpl implements JSONService {

	Logger logger = Logger.getLogger(JSONServiceImpl.class);

	public Map<String, Issue> jsonToMap(String fileName) {
		Issue issue = null;
		Map<String, Issue> issues = null;
		Object jsonResponse = null;
		Iterator<Map.Entry> itr1 = null;
		Iterator itr2 = null;
		String key = null;
		try {
			jsonResponse = new JSONUtil().getValue(fileName, Constants.key);
			issues = new HashMap<>();
			JSONArray jsonArray = (JSONArray) jsonResponse;
			// iterating array
			itr2 = jsonArray.iterator();
			int count = 0;
			while (itr2.hasNext()) {
				issue = new Issue();
				itr1 = ((Map) itr2.next()).entrySet().iterator();
				while (itr1.hasNext()) {
					Map.Entry pair = itr1.next();
					String keyFromMap = (String) pair.getKey();
					if (keyFromMap.equalsIgnoreCase("key")) {
						issue.setIssueKey((String) pair.getValue());
					} else if (keyFromMap.equalsIgnoreCase("component")) {
						issue.setComponent((String) pair.getValue());
					} else if (keyFromMap.equalsIgnoreCase("line")) {
						issue.setLine((Long) pair.getValue());
					} else if (keyFromMap.equalsIgnoreCase("message")) {
						issue.setMessage((String) pair.getValue());
					} else if (keyFromMap.equalsIgnoreCase("author")) {
						issue.setAuthor((String) pair.getValue());
					} else if (keyFromMap.equalsIgnoreCase("creationDate")) {
						issue.setCreatedDate((String) pair.getValue());
					} else if (keyFromMap.equalsIgnoreCase("effort")) {
						issue.setEffort((String) pair.getValue());
					} else if (keyFromMap.equalsIgnoreCase("rule")) {
						issue.setRule((String) pair.getValue());
					}

				}
				issue.setDisplayKey(issue.getComponent().substring(issue.getComponent().lastIndexOf("/") + 1) + " : "
						+ issue.getLine());
				System.out.println(issue);
				key = issue.getIssueKey();
				issues.put(key, issue);
				key = "";
				count++;
				System.out.println(issues.size());
			}
			System.out.println("Count: " + count);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return issues;
	}
}
