package com.zycus.sonarcubeapi.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ApiRequest {
	private String projectKeys;
	private String severities;
	private String statuses;
	private String types;
	private Date createdAfter;
	private String ps;
	private int p;

	/**
	 * Returns formatted date for creating API Request URL
	 * 
	 * @return
	 */
	public String getFormattedDate() {
		return new SimpleDateFormat("yyyy-MM-dd").format(getCreatedAfter());
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public String getProjectKeys() {
		return projectKeys;
	}

	public void setProjectKeys(String projectKeys) {
		this.projectKeys = projectKeys;
	}

	public String getSeverities() {
		return severities;
	}

	public ApiRequest() {
		super();
	}

	public void setSeverities(String severities) {
		this.severities = severities;
	}

	public String getStatuses() {
		return statuses;
	}

	public void setStatuses(String statuses) {
		this.statuses = statuses;
	}

	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	public Date getCreatedAfter() {
		return createdAfter;
	}

	public void setCreatedAfter(Date createdAfter) {
		this.createdAfter = createdAfter;
	}

	@Override
	public String toString() {
		return "ApiRequest [projectKeys=" + projectKeys + ", severities=" + severities + ", statuses=" + statuses
				+ ", types=" + types + ", createdAfter=" + createdAfter + ", ps=" + ps + ", p=" + p + "]";
	}

	public ApiRequest(String projectKeys, String severities, String statuses, String types, Date createdAfter,
			String ps, int p) {
		super();
		this.projectKeys = projectKeys;
		this.severities = severities;
		this.statuses = statuses;
		this.types = types;
		this.createdAfter = createdAfter;
		this.ps = ps;
		this.p = p;
	}

	public String getPs() {
		return ps;
	}

	public void setPs(String ps) {
		this.ps = ps;
	}

}
