package com.zycus.sonarcubeapi.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Logger;

import com.zycus.sonarcubeapi.model.Issue;

public class CommonUtilities {
	Logger logger = Logger.getLogger(CommonUtilities.class);

	public static Map<String, Integer> getAuthors(Map<String, Issue> issues) {

		Map<String, Integer> authors = new HashMap<>();
		for (Map.Entry<String, Issue> entry : issues.entrySet()) {
			if (authors.containsKey(entry.getValue().getAuthor())) {
				authors.put(entry.getValue().getAuthor(), authors.get(entry.getValue().getAuthor()) + 1);
			} else {
				authors.put(entry.getValue().getAuthor(), 1);
			}
		}
		return authors;
	}

	public static int getTotalIssues(Map<String, Integer> authors) {
		int totalIssues = 0;
		for (Entry<String, Integer> entry : authors.entrySet()) {
			totalIssues += entry.getValue();
		}
		return totalIssues;
	}

	public static String generateKey(String component, String line) {
		return component.substring(component.lastIndexOf("/")) + line;
	}

	public static List<String> getAllProjects() {
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream("D:\\Project\\SonarAPIImplementation\\sonarcubeapi\\src\\projectkeys.properties"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Set<Object> set = prop.keySet();
		System.out.println(set);
		List<String> list = new ArrayList<>();
		for (Object object : set) {
			list.add((String) object);
		}
		return list;
	}
	
	public static String getProjectKey(String projectName){
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream("D:\\Project\\SonarAPIImplementation\\sonarcubeapi\\src\\projectkeys.properties"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		return prop.getProperty(projectName);
	}
}
