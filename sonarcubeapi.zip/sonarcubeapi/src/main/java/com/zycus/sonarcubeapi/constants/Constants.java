package com.zycus.sonarcubeapi.constants;

public interface Constants {
	static String baseURL = "http://192.168.1.186:9003/";
	static String apiPath = "api/issues/search";
	static String get="GET";
	static String key="issues";
			
}
